/**
 * 
 */

/**
 * @author amorales
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("|||||||||    |||     |||      |||");
		System.out.println("|||   |||    |||      |||    |||");
		System.out.println("|||   |||    |||       |||  |||");
		System.out.println("|||||||||    |||         |||");
		System.out.println("|||   |||    |||         |||");
		System.out.println("|||   |||    ||||||      |||");
		
	}

}
